#include <stdio.h>

int main()
{
    printf("Give me a number.\n");
    int i = 0;
    scanf("%d", &i);
    printf("You wrote: %d\n", i);
    return 0;
}

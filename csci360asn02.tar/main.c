/**********************************************************************
* Title:    main.c
*
* Author:   Andrew Smythe
*
* Date:     November 16th, 2012
*
* Purpose:  Main routine for Virtual Filesystem Simulator. Uses an
*           ordinary file (Linux) to simulate a disk, and uses i-nodes.
*
**********************************************************************/

// Includes
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include "disk.h"

// Functions for I/O
void getReadFile(struct Disk* d);
void getWriteFile(struct Disk* d);

int main(int argc, char ** argv)
{
    // Virtual disk information
    struct Disk d;
    
	printf("************************************************\n");
	printf("        Andrew's Virtual Disk Manager\n");
	printf("************************************************\n");
	
	char answer[255];
	int run = 1;
    // Run a loop for execution of the program
    while (run)
    {
	    printf("\nOptions:\n");
	    printf("--------------------------------\n");
	    printf("\t1 - Format Disk\n");
	    printf("\t2 - Mount Disk\n");
	    printf("\t3 - Randomly Fill Disk\n");
	    printf("\t4 - Save file to disk\n");
	    printf("\t5 - Read file from disk\n");
	    printf("\t6 - Unmount Disk\n");
	    printf("\tq - Quit\n");
	    
	    scanf(" %s",answer);
		switch(answer[0]) {
			case '1': formatDisk(&d); 		break;
			case '2': mountDisk(&d);		break;
			case '3': fillBlocks(&d);     	break;
			case '4': getWriteFile(&d);      break;
			case '5': getReadFile(&d);       break;
			case '6': unmountDisk(&d);		break;
			case 'q':
			case 'Q': run = 0;              break;
			default: printf("\tPlease try again.\n");
		}
    }
    
	return 0;
}

/*
    Functions for I/O
*/

void getWriteFile(struct Disk* d)
{
    char filename[255];
    while(1) {
        // prompt user for a filename
        printf("\nEnter name of file (local) to write to disk:\n");
        scanf("%s", filename);
        
        // attempt to open file
        FILE *f = fopen(filename, "r+");
        if (f != NULL) {
            writeFile(f, d);
            fclose(f);
            // end loop
            break;
        }
        printf("Could not open file. Please try again.\n");
    }

}

void getReadFile(struct Disk* d)
{
    char filename[255];
    int filenum;
    while (1) {
        // prompt user for number of file to open
        printf("\nEnter file number to read:\n");
        scanf("%d", &filenum);
        
        // prompt user for filename
        printf("\nEnter name of local file to write to:\n");
        scanf("%s", filename);
        
        // attempt to write to file
        FILE *f = fopen(filename, "w+");
        if (f != NULL) {
            readFile(f, d, filenum-1);
            printf("\nWritten to: %s\n", filename);
            fclose(f);
            //end loop
            break;
        }
        printf("Could not open file. Please try again.\n");
    }
}
    /*formatDisk(&d);
    mountDisk(&d);
    fillBlocks(&d);
    
    FILE *f = fopen("asdf.txt", "r+");
    writeFile(f, &d);
    fclose(f);
    
    f = fopen("asdf2.txt", "w+");
    readFile(f, &d, 0);
    fclose(f);
    
    unmountDisk(&d);*/

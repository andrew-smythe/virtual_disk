/**********************************************************************
* Title:    disk.c
*
* Author:   Andrew Smythe
*
* Date:     November 16th, 2012
*
* Purpose:  Implementation of disk manipulation functions.
*
**********************************************************************/

// Includes
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <math.h>
#include "block.h"
#include "disk.h"

// formatDisk -- opens/creates a new virtual disk, and writes i-nodes
//               and free space management blocks to disk.
extern void formatDisk(struct Disk *d)
{
    // open file for writing -- overwrite any old disk
    d->fp = fopen("vdisk", "w+");
    
    // construct buffer, and write buffer to file
    int disksize = NBLOCKS * BLOCKSIZE;
    unsigned char * buffer = (unsigned char *)malloc(disksize*sizeof(unsigned char));
    if (buffer == NULL) {
        printf("Error allocating memory!");
        return;
    }
    
    int i =0;
    for (i = 0; i < disksize; i++)
        buffer[i] = 0;
        
    // Write buffer to disk
    fwrite(buffer, 1, disksize, d->fp);
    
    // we don't need the buffer anymore
    free(buffer);
    
    // construct a new buffer that will make a super block
    buffer = (unsigned char *)malloc (BLOCKSIZE*sizeof(unsigned char));
    if (buffer == NULL) {
        printf("Error allocating memory!");
        return;
    }
    
    // number of blocks for free space management
    buffer[FSM_BIT] = FSM;
    
    // number of i-nodes block
    buffer[INODE_BIT] = INODES;
    buffer[N_BIT] = 200;
    
    // Write buffer to disk
    rewind(d->fp);
    fwrite(buffer, 1, BLOCKSIZE, d->fp);
    
    // get rid of buffer
    free(buffer);
    
    // close the file
    fclose(d->fp);
    
    // Success message
    printf("Disk was formatted -- ./vdisk\n");
}

// mountDisk -- loads virtual disk from file
extern void mountDisk(struct Disk *d)
{
    // open virtualdisk for reading/writing -- do not overwrite
	d->fp = fopen("vdisk", "r+");
	
	// create a buffer that can hold one block at a time
	d->super = (unsigned char *)malloc(BLOCKSIZE*sizeof(unsigned char));
	if (d->super == NULL) {
	    printf("Error allocating memory!");
	    return;
	}
	
	// load super block into buffer
	rewind(d->fp);
	int read = fread(d->super, 1, BLOCKSIZE, d->fp);
	
	// set some flags on disk
    d->FSM_SIZE = d->super[FSM_BIT];
    d->FSM_START = BLOCKSIZE;
	d->INODES_SIZE = d->super[INODE_BIT];
	d->INODES_START = BLOCKSIZE*d->FSM_SIZE+d->FSM_START;
	d->NBLOCKS = d->super[N_BIT];
	d->DBLOCKS_START = (BLOCKSIZE*d->FSM_SIZE)+(BLOCKSIZE*d->INODES_SIZE)+d->FSM_START;
	
	// allocate d->blockStatus array
	d->blockStatus = (unsigned char *)malloc((d->FSM_SIZE*BLOCKSIZE)*sizeof(unsigned char));
	if (d->blockStatus == NULL) {
	    printf("Error allocating memory!");
	    return;
	}
	
	// get free space management blocks
	fseek(d->fp, d->FSM_START, SEEK_SET);
	read = fread(d->blockStatus, 1, d->FSM_SIZE*BLOCKSIZE, d->fp);
    if (read != d->FSM_SIZE*BLOCKSIZE) {
        perror("Could not read Free Space Management");
        printf("\nREAD: %d\n", read);
        return;
    }
    
	// allocate inodes array
	d->inodes = (unsigned char *)malloc((d->INODES_SIZE*BLOCKSIZE)*sizeof(unsigned char));
	if (d->inodes == NULL) {
	    printf("Error allocating memory!");
	    return;
	}
    
    // get i-node blocks
    fseek(d->fp, d->INODES_START, SEEK_SET);
    read = fread(d->inodes, 1, d->INODES_SIZE*BLOCKSIZE, d->fp);
    if (read != d->INODES_SIZE*BLOCKSIZE) {
        perror("Could not read I-nodes");
        printf("\nREAD: %d\n", read);
        return;
    }
    
	// allocate data blocks array
	d->dblocks = (unsigned char *)malloc((d->NBLOCKS*BLOCKSIZE)*sizeof(unsigned char));
	if (d->dblocks == NULL) {
	    printf("Error allocating memory!");
	    return;
	}
	
    // get data blocks
    fseek(d->fp, d->DBLOCKS_START, SEEK_SET);
    read = fread(d->dblocks, 1, d->NBLOCKS*BLOCKSIZE, d->fp);
    if (read != d->NBLOCKS*BLOCKSIZE) {
        perror("Could not read I-nodes");
        printf("\nREAD: %d\n", read);
        return;
    }
    
    // Success message
    printf("Successfully mounted drive at ./vdisk\n");
    char ch;
    printf("Press enter to continue...\n");
    while (getchar() != '\n');
}

// fillBlocks -- sets roughly half of the blocks to full
extern void fillBlocks(struct Disk *d)
{
    // check if the FSM bitmap has been set
    if (d->blockStatus == NULL) {
        // allocate space for FSM bitmap
        d->blockStatus = (unsigned char *)malloc((d->FSM_SIZE*BLOCKSIZE)*sizeof(unsigned char));
	    if (d->blockStatus == NULL) {
	        printf("Error allocating memory!");
	        return;
	    }
	    // set all blocks to zero -- unused
	    int i = 0;
	    for (i = 0; i < d->FSM_SIZE*BLOCKSIZE; i++) d->blockStatus[i] = 0;
	}
	
	// seed a random number generator
	srand(time(NULL));
	
	// set some blocks to 1
	int i = 0;
	for (i = 0; i < d->FSM_SIZE*BLOCKSIZE; i++) {
	    int blockNum = rand()%d->NBLOCKS;
	    if (blockNum != 0) d->blockStatus[blockNum] = 1;
	}
	d->blockStatus[0] = 1;
    // Success message
    printf("Randomly filled half of the blocks.\n");
}

// unmountDisk --  writes changes to disk, closes virtual disk file
extern void unmountDisk(struct Disk *d)
{
    // Write the disk information back to the virtual disk file,
    // starting with the super block
    rewind(d->fp);
    fwrite(d->super, 1, BLOCKSIZE, d->fp);
    
    // free space management blocks
    fwrite(d->blockStatus, 1, BLOCKSIZE*d->FSM_SIZE, d->fp);
    
    // i-node blocks
    fwrite(d->inodes, 1, BLOCKSIZE*d->INODES_SIZE, d->fp);
    
    // data blocks
    fwrite(d->dblocks, 1, BLOCKSIZE*d->NBLOCKS, d->fp);
    
    // close the file, free the disk info
    fclose(d->fp);
    free(d->super);
    free(d->blockStatus);
    free(d->inodes);
    free(d->dblocks);
    
    // Success message
    printf("Successfully wrote disk to ./vdisk.\n");
    
}

// checkFull -- checks if a block is full or empty
extern int checkFull(int blockNum, struct Disk *d)
{
    return (d->blockStatus[blockNum] == 1);
}


// setFull -- set a block to full
extern void setFull(int blockNum, struct Disk *d)
{
    d->blockStatus[blockNum] = 1;
}

// getFileSize -- get size of an open file
extern long int getFileSize(FILE *fp)
{
    fseek(fp, 0L, SEEK_END);
    int size = ftell(fp);
    fseek(fp, 0L, SEEK_SET);
    return size;
}

// writeFile -- write a file to the file system
extern void writeFile(FILE *fp, struct Disk* d)
{
    // get the size of the file
    int fileSize = getFileSize(fp);
    
    // calculate how many blocks it will take
    int numBlocks = ceil((float)fileSize / (float)BLOCKSIZE);
    
    if (totalFree(d) < numBlocks) {
        printf("Not enough space left on disk!");
        return;
    }
    
    // write a new inode to inode block
    int i = 0;
    int inode = 0;
    for (i = 0; i < BLOCKSIZE; i++) {
        if (d->inodes[i] == 0) {
            inode = i;
            break;
        }
    }
    
    // set pointer to new inode block
    int inodeBlock = nextBlock(d);
    d->inodes[inode] = inodeBlock;
    setFull(inodeBlock, d);
    
    // write block numbers for new file into the inode block
    int blockNum = (inodeBlock*BLOCKSIZE)+d->DBLOCKS_START;
    
    unsigned char * buffer = (unsigned char *)malloc(BLOCKSIZE*sizeof(unsigned char*));
    if (buffer == NULL) {
        printf("Out of memory.");
        return;
    }
    
    // begin writing block numbers, and then write file information to
    // the block
    for (i = 0; i < numBlocks; i++) {
        int next = nextBlock(d);
        d->dblocks[inodeBlock+i] = next;
        d->dblocks[blockNum+i] = next;
        setFull(next, d);
        int read = fread(buffer, 1, BLOCKSIZE, fp);
        if (read != BLOCKSIZE && i != numBlocks-1) {
            perror("Could not read file");
            return;
        }
        int j = 0;
        int infoBlock = (next*BLOCKSIZE)+d->DBLOCKS_START;
        for (j = 0; j < BLOCKSIZE; j++)
            d->dblocks[infoBlock+j] = buffer[j];
    }
        
    // Success message
    printf("Wrote file to file #%d.\n", inode+1);
}

// readFile -- reads the nth file on the file system, return 0 if failed
extern int readFile(FILE *fp, struct Disk* d, int n) {
    // check if file exists on disk
    if (d->inodes[n] == 0 && d->dblocks[0] == 0)
        return 0;
        
    // find the inode block
    int i = 0;
    int inodeBlock = d->inodes[n];
    int inodeBlockNum = (inodeBlock*BLOCKSIZE)+d->DBLOCKS_START;
    
    // determine how many blocks are in file
    int numBlocks = 0; i = 0;
    while (d->dblocks[inodeBlock+i] != 0) {
        numBlocks++;
        i++;
    }
    
    // buffer for holding block information
    unsigned char * buffer = (unsigned char *)malloc(BLOCKSIZE*sizeof(unsigned char*));
    if (buffer == NULL) {
        printf("Out of memory.");
        return 0;
    }
    
    // read file from the filesystem, write to outside file
    for (i = 0; i < numBlocks; i++) {
        // current block
        int num = d->dblocks[inodeBlock+i];
        int currBlockNum = (num*BLOCKSIZE)+d->DBLOCKS_START;
        int j = 0;
        
        // put information into buffer
        for (j = 0; j < BLOCKSIZE; j++)
            buffer[j] = d->dblocks[currBlockNum+j];
            
        // write buffer to file
        int written = fwrite(buffer, 1, BLOCKSIZE, fp);
        if (written != BLOCKSIZE && i != numBlocks-1) {
            perror("Could not write to file.");
            return 0;
        }
    }
    // Success message
    printf("File #%d re-written to disk.\n", n+1);
    return 1;
}

// totalFree -- return number of total free blocks remaining
extern int totalFree(struct Disk* d)
{
    int count = 0;
    int i = 0;
    for (i = 0; i < NBLOCKS; i++) {
        if (d->blockStatus[i] == 0) count++;
    }
    return count;
}

// nextBlock -- returns the number of the next free block on disk
extern int nextBlock(struct Disk* d)
{
    int blockNum = 0;
    int i = 0;
    for (i = 0; i < NBLOCKS; i++) {
        if (d->blockStatus[i] == 0) return i;
    }
    return -1; // no free blocks
}


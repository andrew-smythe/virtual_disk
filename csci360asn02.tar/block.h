/**********************************************************************
* Title:    block.h
*
* Author:   Andrew Smythe
*
* Date:     November 16th, 2012
*
* Purpose:  Constants for block sizes.
*
**********************************************************************/
#ifndef BLOCK_H
#define BLOCK_H

#define BNUM 200
#define SUPERBLOCK 1
#define FSM 4
#define INODES 1

#define FSM_BIT 0
#define INODE_BIT 1
#define N_BIT 2

const int BLOCKSIZE = 50;
const int NBLOCKS =   BNUM + SUPERBLOCK + FSM + INODES;

#endif
